var cup_info = {
	dodo: {
		name: "Dodo cup",
		song: "env2.mp3"
	},
	carrot: {
		name: "Carrot cup",
		song: "tokyo.mp3"
	},
	skilled: {
		name: "Skilled cup",
		song: "env2.mp3"
	},
	furby: {
		name: "Furby cup",
		song: "tokyo.mp3"
	},
	doom: {
		name: "Doom cup",
		song: "env2.mp3"
	},
	rocky: {
		name: "Rocky cup",
		song: "stairways.mp3"
	},
	kazil: {
		name: "Kazil cup",
		song: "stairways.mp3"
	},
	tim: {
		name: "Tim cup",
		song: "tokyo.mp3"
	},
	crazy: {
		name: "Crazy cup",
		song: "tokyo.mp3"
	},
	june: {
		name: "June cup",
		song: "stairways.mp3"
	},
	sleepy: {
		name: "Sleepy cup",
		song: "env2.mp3"
	},
	mango: {
		name: "Mango cup",
		song: "tokyo.mp3"
	},
	squirrel: {
		name: "Squirrel cup",
		song: "stairways.mp3"
	},
	collab: {
		name: "Collab cup",
		song: "env2.mp3"
	},
}