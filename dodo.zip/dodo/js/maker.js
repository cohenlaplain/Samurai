var maker = {
    platform_count: 0,
    cone_count: 0,
    cylinder_count: 0,
    sphere_count: 0,
    ending_count: 0,
    plat1: null,
    plat2: null,
    plat3: null,
    init: function() {
        this.add_root_meshes("cone", 2, (i) => {
            return BABYLON.Mesh.CreateCylinder("cone"+i, 1.0, 0.0, 1.0, 5, 1, scene, false, BABYLON.Mesh.DEFAULTSIDE);
        });
        this.add_root_meshes("plat", 4, (i) => {
            return BABYLON.Mesh.CreateBox("plat"+i,1, scene);
        });
        this.add_root_meshes("sphere", 5, (i) => {
            return BABYLON.Mesh.CreateSphere("sphere"+i, 10, 1, scene);
        });
    },
    add_root_meshes: function(name, count, fn) {
        for (var i=0;i<count;i++) {
            this[name+i] = fn(i);
            decorations.decorate(this[name+i], name+i);
            this[name+i].isVisible = false;
            this[name+i].cullingStrategy = BABYLON.AbstractMesh.CULLINGSTRATEGY_BOUNDINGSPHERE_ONLY;
        }  
    },
    make_platform: function(posList, rotList, sizList, imat=0, bounce=0, mass=0, friction=0.6, jump=false) {
        // Data
        let pX = posList[0]; let pY = posList[1]; let pZ = posList[2];
        let rX = rotList[1]; let rY = rotList[0]; let rZ = rotList[2];
        let sX = sizList[0]; let sY = sizList[1]; let sZ = sizList[2];
        pY += Math.random() * 0.0007;
        // Mesh
        let mesh_name = "P" + this.platform_count;
        var platform = (this["plat"+imat] || this["plat"+0]).createInstance(mesh_name);
        if (imat == -1) platform.isVisible = false;
        // Set
        platform.scaling = new BABYLON.Vector3(sX,sY,sZ);
        platform.position = new BABYLON.Vector3(pX,pY,pZ);
        platform.rotation = new BABYLON.Vector3(rX,rY,rZ);
        // platform.freezeWorldMatrix(); // Don't use:  ???
        // Physics
        platform.physicsImpostor = new BABYLON.PhysicsImpostor(platform, BABYLON.PhysicsImpostor.BoxImpostor, { mass: mass, restitution: bounce, friction: friction}, scene);
        // Tracker
        this.platform_count += 1;
        if (jump == true) {
            jumppads.push(platform);
        }
    },
    make_cone: function(posList, iceparty) {
        // Data
        let pX = posList[0]; let pY = posList[1]; let pZ = posList[2];
        // Mesh
        let mesh_name = "C" + this.cone_count;
        var imat = (iceparty == true) ? 1 : 0;
        var cone = (this["cone"+imat] || this["cone"+0]).createInstance(mesh_name);
        if (imat == -1) cone.isVisible = false;
        // Set
        cone.position = new BABYLON.Vector3(pX,pY,pZ);
        cone.scaling.y = 1.2;
        cone.freezeWorldMatrix();
        // Tracker
        cones.push(cone);
        this.cone_count += 1;
    },
    make_sphere: function(posList, r, imat=0, bounce=0, mass=0, friction=0.6) {
        // Data
        let pX = posList[0]; let pY = posList[1]; let pZ = posList[2];
        // Mesh
        let mesh_name = "S" + this.sphere_count;
        var sphere = (this["sphere"+imat] || this["sphere"+0]).createInstance(mesh_name);
        if (imat == -1) sphere.isVisible = false;
        // Set
        sphere.position = new BABYLON.Vector3(pX,pY,pZ);
        sphere.scaling = new BABYLON.Vector3(r,r,r);
        sphere.freezeWorldMatrix(); // // Don't use: ???
        // Physics
        sphere.physicsImpostor = new BABYLON.PhysicsImpostor(sphere, BABYLON.PhysicsImpostor.SphereImpostor, { mass: mass, restitution: bounce, friction: friction }, scene);
        // Tracker
        this.sphere_count += 1;
    },
    make_ending: function(posList) {
        // Data
        let pX = posList[0]; let pY = posList[1]; let pZ = posList[2];
        // Mesh
        let mesh_name = "E" + this.ending_count;
        var ending = BABYLON.Mesh.CreateCylinder(mesh_name, 2.0, 2.0, 2.0, 8, 1, scene, false, BABYLON.Mesh.DEFAULTSIDE);
        ending.position = new BABYLON.Vector3(pX, pY, pZ);
        // Visuals
        ending.material = decorations.materials.ending;
        ending.freezeWorldMatrix();
        // Physics
        endings.push(ending);
        this.ending_count += 1;
    },
    make_cylinder: function(posList, rotList, sizList, imat=0, bounce=0, mass=0, friction=0.6) {
        // Data
        let pX = posList[0]; let pY = posList[1]; let pZ = posList[2];
        let rX = rotList[1]; let rY = rotList[0]; let rZ = rotList[2];
        let sX = sizList[0]; let sY = sizList[1]; let sZ = sizList[2];
        
        const height = 1;//sY;
        const radius = 1;//sZ;

        var mesh = BABYLON.Mesh.CreateCylinder("Y" + this.cylinder_count, height, radius, radius, 12, 1, scene, false, BABYLON.Mesh.DEFAULTSIDE);
        mesh.scaling = new BABYLON.Vector3(sX,sY,sZ);
        mesh.position = new BABYLON.Vector3(pX,pY,pZ);
        mesh.rotation = new BABYLON.Vector3(rX,rY,rZ);
        mesh.physicsImpostor = new BABYLON.PhysicsImpostor(mesh, BABYLON.PhysicsImpostor.CylinderImpostor, { mass: mass, restitution: bounce, friction: friction }, scene);
        
        decorations.decorate(mesh, "cylinder"+imat);
        if (imat == -1) mesh.isVisible = false;
        this.cylinder_count += 1;
    },
    make_start: function(posList) {
        let pX = posList[0]; let pY = posList[1]; let pZ = posList[2];
        this.make_platform([pX,pY,pZ+9], [0,0,0], [3,0.5, 14]);
    }

}

